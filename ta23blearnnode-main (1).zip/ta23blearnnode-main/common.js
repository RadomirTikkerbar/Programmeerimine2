module.exports = {
    hello(){
        console.log('hellocommon js');
    }
}