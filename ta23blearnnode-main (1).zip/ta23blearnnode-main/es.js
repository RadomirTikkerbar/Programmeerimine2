export default {
    hello(){
        console.log('Hello es module');
    }
}